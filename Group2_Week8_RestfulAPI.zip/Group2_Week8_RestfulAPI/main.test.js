const supertest = require('supertest');
const request = supertest('http://localhost:3000');

describe('Express Route Test', function () {
	it('login successfully', async () => {
		return request
			.post('/login')
			.send({username: 'Ming', password: "p@ss" })
			.expect('Content-Type', /text/)
			.then(res => {
				expect(res.text).toBe('Login successfully');
			});
	});

	it('login failed', async () => {
		return request
			.post('/login')
			.send({username: 'Ming', password: "pass" })
			.expect('Content-Type', /text/)
			.then(res => {
				expect(res.text).toBe('Invalid username or password');
			});
	})

	it('register', async () => {
		return request
			.post('/register')
			.send({username: 'Ming2', password: "p@ss", phone: "123456" })
			.expect('Content-Type', /text/)
			.then(res => {
				expect(res.text).toBe('Register successfully');
			});
	});

	it('register failed', async () => {
		return request
			.post('/register')
			.send({username: 'Ming', password: "p@ss", phone: "123456" })
			.expect('Content-Type', /text/)
			.then(res => {
				expect(res.text).toBe('Username already exists');
			});
	})
});