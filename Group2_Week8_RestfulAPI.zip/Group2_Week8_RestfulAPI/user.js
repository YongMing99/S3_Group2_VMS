const md5 = require('md5');

let users;

class User {
	static async injectDB(conn) {
		users = await conn.db("assignment_g2").collection("users")
	}

	/**
	 * @remarks
	 * This method is not implemented yet. To register a new user, you need to call this method.
	 * 
	 * @param {*} username 
	 * @param {*} password 
	 * @param {*} phone 
	 */
	static async register(username, password, phone) {
		// TODO: Check if username exists
		var username_check = await users.find({username: username}).count()

		if (username_check>0) {
			console.log(username_check)
			return "Username already exists"
		}
		// TODO: Hash password
		// TODO: Save user to database
		else{
			var hash_password = await md5(password)
			var user = await users.insertOne({username: username, password: hash_password, phone: phone})
			console.log("User registered")
			return users.find({username: username}).toArray()
		}
		
		// faker.js
		// return
	}

	static async login(username, user_password) {
		// TODO: Check if username exists
		var username_count = await users.find({username: username}).count();
		console.log(username_count)
		if (username_count > 0) {
		// TODO: Validate password
			var password_check = await md5(user_password)
			var password_check_db = await users.find({username: username}).toArray()
			console.log(username_count)
			if (password_check_db[0].password == password_check) {
		// TODO: Return user object
				return users.find({username: username}).toArray()
			}
			else{
				return "Invalid password"
			}
		}
		else{
			return "Invalid username"
		}
		// faker.js
		return
	}
}

module.exports = User;